package org.atlis.server.net;

public enum SessionState {
    KEY_EXCHANGE,
    PROTOCOL,
    LOGGED_IN
}
