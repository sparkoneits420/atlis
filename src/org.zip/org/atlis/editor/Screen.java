package org.atlis.editor;

import org.atlis.editor.build.NPCBuilder;
import org.atlis.editor.build.ObjectBuilder;
import org.atlis.editor.add.AddNPC;
import org.atlis.editor.add.AddObject;
import org.atlis.common.tsk.Task;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import org.atlis.common.model.GameObject;
import org.atlis.common.model.NPC;
import org.atlis.common.model.Region;
import org.atlis.common.model.Tile;
import org.atlis.common.util.Constants;
import org.atlis.common.util.XMLPersistence;
import org.atlis.common.util.Utilities;

public class Screen extends JPanel implements MouseMotionListener, MouseListener, ActionListener, KeyListener {

    public static int currentX = 0, currentY = 0;
    public static boolean initialized = false, addingObject = false;
    public static boolean addingNPC;
    public boolean changedLocation;

    public GameObject objectSelected;
    public static NPC npcToAdd;
    public Region region;
    public ArrayList<Tile> selected, modified;
    public static GameObject objectToAdd;
    public HashMap<Long, Region> cachedRegions;
    public int mouseX, mouseY;

    public Screen() {

        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        modified = new ArrayList<>();
        selected = new ArrayList<>();
        cachedRegions = new HashMap<>();
        MapEditor.getTaskPool().add(
                new Task(Constants.PAINT_INTERVAL) {
            @Override
            public void execute() {
                repaint();
            }
        });
    }

    @Override
    public void paintComponent(Graphics g) {
        Image image = this.createImage(getWidth(), getHeight());
        Graphics g2 = image.getGraphics();
        if (!initialized) {
            if (region == null) {
                region = XMLPersistence.loadXML(Constants.CACHE_DIR + "/mapdata/" + Utilities.intsToLong(currentX, currentY) + ".xml");
                System.out.println("tried loading region");
            }
            // System.out.println("generating surrounding regions, center null");
            generateSurroundingRegions();

            initialized = true;
        } else {
            g2.translate((getWidth() / 2) - currentX, (getHeight() / 2) - currentY);
            if (region == null) {
                MapEditor.getLog().put("null");
                return;
            }
            for (Tile tile : region.values()) {
                if (tile.isVisible(currentX, currentY, this)) {
                    g2.drawImage(tile.getImage(), tile.getX(), tile.getY(), this);
                    g2.setColor(Color.GREEN);
                    g2.drawRect(tile.getX(), tile.getY(), 16, 16);
                }
            }
            int paintedRegions = 0;
            for (Region visRegion : cachedRegions.values()) {
                if (visRegion == region) {
                    continue;
                }
                if (visRegion.isVisible(region)) {
                    paintedRegions++;
                    //MapEditor.getLog().put("painting region");
                    for (Tile tile : visRegion.values()) {
                        if (tile.isVisible(currentX, currentY, this)) {
                            g2.drawImage(tile.getImage(), tile.getX(), tile.getY(), this);
                            g2.setColor(Color.GREEN);
                            g2.drawRect(tile.getX(), tile.getY(), 16, 16);
                        }
                    }
                } else {
                    //System.out.println("region not visible");
                }
            }
            //MapEditor.getLog().put("Painted {" + paintedRegions + "} regions");
            for (Tile tile : selected) {
                g2.setColor(Color.BLACK);
                g2.drawRect(tile.getX(), tile.getY(), 16, 16);
            }
        }

        if (objectToAdd != null && objectToAdd.images != null) {
            if (objectToAdd.currentImageSlot < objectToAdd.images.length - 1) {
                objectToAdd.currentImageSlot++;
            } else {
                objectToAdd.currentImageSlot = 0;
            }

            g2.drawImage(objectToAdd.images[objectToAdd.currentImageSlot], objectToAdd.getX(), objectToAdd.getY(), this);
        }

        if (npcToAdd != null && npcToAdd.idle != null) {
            g2.drawImage(npcToAdd.idle, npcToAdd.getX(), npcToAdd.getY(), this);
        }
        //MapEditor.getLog().put("Objects loaded: " + region.objects.size());
        if (!region.objects.isEmpty() && region.objects != null) {
            for (GameObject object : region.objects) {
                if (object.images == null) {
                    continue;
                }
                if (object.currentImageSlot < object.images.length - 1) {
                    object.currentImageSlot++;
                } else {
                    object.currentImageSlot = 0;
                }
                g2.drawImage(object.images[object.currentImageSlot], object.getX(), object.getY(), this);

            }
        }

        //MapEditor.getLog().put("Objects loaded: " + region.objects.size());
        if (!region.npcs.isEmpty() && region.npcs != null) {
            for (NPC npc : region.npcs) {
                if (npc.idle == null) {
                    continue;
                }
                g2.drawImage(npc.idle, npc.getX(), npc.getY(), this);
                // npc.handleMovement(g);
            }
        }

        if (objectSelected != null) {
            g2.setColor(Color.RED);
            g2.drawRect(objectSelected.getX(), objectSelected.getY(), objectSelected.getWidth(), objectSelected.getHeight());
        }

        //MapEditor.getLog().put(getWidth() + ", " + getHeight());
        g.drawImage(image, 0, 0, this);
    }

    private void generateSurroundingRegions() {
        int regionSize = Constants.REGION_SIZE;
        int radius = 1;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                int rx = currentX + dx * regionSize;
                int ry = currentY + dy * regionSize;
                long regionId = Utilities.intsToLong(rx, ry);

                Region sRegion = cachedRegions.get(regionId);
                if (sRegion == null) {
                    sRegion = (Region) XMLPersistence.loadXML(Constants.CACHE_DIR + "/mapdata/" + Utilities.intsToLong(rx, ry) + ".xml");
                    if (sRegion == null) {
                        sRegion = new Region(rx, ry);
                        MapEditor.getLog().put("Region is null, creating new: " + regionId);
                    } else {
                        for (GameObject obj : sRegion.getObjects()) {
                            obj.loadImages();
                        }
                    }
                }

                if (rx == currentX && ry == currentY) {
                    region = sRegion;
                    MapEditor.getLog().put("Caching center region");
                }

                if (!cachedRegions.containsKey(regionId)) {
                    cachedRegions.put(regionId, sRegion);
                }
            }
        }
        MapEditor.getLog().put("Preloaded regions: " + cachedRegions.size());
    }

    @Override
    public void mouseClicked(MouseEvent e) {

        if (addingObject) {

        }

        for (GameObject o : region.objects) {
            if (o == null) {
                continue;
            }
            //if (o.withinBounds()) {
              //  objectSelected = o;
                //return;
            //}
        }
        Tile tile = getTile((e.getX() + currentX) - (getWidth() / 2),
                (e.getY() + currentY) - (getHeight() / 2));
        if (tile == null) {
            return;
        }
        if (!selected.contains(tile)) {
            //region.remove(tile);
            selected.add(tile);
        } else if (selected.contains(tile)) {
            selected.remove(tile);
            //region.add(tile);
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        int x = (e.getX() + currentX) - (getWidth() / 2),
                y = (e.getY() + currentY) - (getHeight() / 2);
        if (addingObject) {
            objectToAdd.setLocation(x - objectToAdd.getWidth() / 2, y - objectToAdd.getHeight() / 2);
            objectToAdd.setBounds();
            return;
        }

        if (addingNPC) {
            npcToAdd.setLocation(x - npcToAdd.width / 2, y - npcToAdd.height / 2);
            npcToAdd.setBounds();
        }

        /*
        for(GameObject o : region.objects) {
            if(o == null) {
                continue;
            }
            if(o.withinBoundry(x, y)) {
                objectSelected = o;
            }
            if(objectSelected != null) {
                o.setLocation(x, y);
                return;
            }
        }
         */
        Tile tile = getTile(x, y);
        if (tile == null) {
            return;
        }
        if (!selected.contains(tile)) {
            selected.add(tile);
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        mouseX = e.getX();
        mouseY = e.getY();
    }

    public Tile getTile(int x, int y) {

        for (Region aRegion : cachedRegions.values()) {
            for (Tile tile : aRegion.values()) {
                if (tile == null) {
                    continue;
                }
                int j = tile.x + 16, k = tile.y + 16;
                if ((x <= j && x >= tile.x) && (y <= k && y >= tile.y)) {
                    return tile;
                }
            }
        }
        for (Tile tile : selected) {
            if (tile == null) {
                continue;
            }
            int j = tile.x + 16, k = tile.y + 16;
            if ((x <= j && x >= tile.x) && (y <= k && y >= tile.y)) {
                return tile;
            }
        }

        return null;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand().toLowerCase()) {
            case "replace" -> {
                Object[] options = {"Grass-0", "Stone-1"};
                Object j = JOptionPane.showInputDialog(this,
                        "Choose a replacement tile.",
                        "", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                ArrayList<Tile> temp = new ArrayList<>(selected);
                int newType = Integer.parseInt(j.toString().split("-")[1]);

                for (Tile tile : temp) {
                    long tileId = Utilities.intsToLong(tile.x, tile.y);
                    region.remove(tileId);
                    region.save = true;
                    tile.setType(newType);
                    region.put(tileId, tile);
                }
 
                selected.removeAll(temp);  // <== move deletion here, safely
                temp.clear();
            }
             
            case "log dump" -> {
                MapEditor.getLog().dump();
            }

            case "create object" -> {
                ObjectBuilder.open();
            }
            case "add object" -> {
                AddObject.open();
            }

            case "create npc" -> {
                NPCBuilder.open();
            }

            case "add npc" -> {
                AddNPC.open();
            }

            case "save" -> {
                for (Region r : cachedRegions.values()) {
                    XMLPersistence.saveXML(r);
                }
            }

        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!cachedRegions.containsValue(region) && region != null) {
            cachedRegions.put(region.getId(), region);
        }
        switch (e.getKeyCode()) {
            case KeyEvent.VK_UP -> {
                currentY -= Constants.REGION_SIZE;
                changedLocation = true;
            }
            case KeyEvent.VK_DOWN -> {
                currentY += Constants.REGION_SIZE;
                changedLocation = true;
            }
            case KeyEvent.VK_LEFT -> {
                currentX -= Constants.REGION_SIZE;
                changedLocation = true;
            }
            case KeyEvent.VK_RIGHT -> {
                currentX += Constants.REGION_SIZE;
                changedLocation = true;
            }
            case KeyEvent.VK_ENTER -> {
                if (objectToAdd != null && addingObject) {
                    region.getObjects().add(objectToAdd);
                    objectToAdd = null;
                    addingObject = false;
                }
                if (npcToAdd != null && addingNPC) {
                    region.getNPCs().add(npcToAdd);
                    npcToAdd = null;
                    addingNPC = false;
                }
                if (objectSelected != null) {
                    objectSelected.setBounds();
                    objectSelected = null;
                }
            }
        }
        if (changedLocation) {
            generateSurroundingRegions();
            long regionId = Utilities.intsToLong(currentX, currentY);
            //MapEditor.getLog().put("Region ID: " + regionId);
            int[] ints = Utilities.longToInts(regionId);
            //MapEditor.getLog().put(ints[0] + ", " + ints[1]);
            if (cachedRegions.containsKey(regionId)) {
                //MapEditor.getLog().put("Cached");
                region = cachedRegions.get(regionId);
                //MapEditor.getLog().put("Cached: X: " + currentX + ", Y: " + currentY);
            } else {
                //MapEditor.getLog().put("Not cached");
                region = XMLPersistence.loadXML(Constants.CACHE_DIR + "/mapdata/" + Utilities.intsToLong(ints[0], ints[1]) + ".xml");
                if (region == null) {
                    //MapEditor.getLog().put("Generation new regions because region is null");

                    //generateRegion();
                }
                //cachedRegions.put(region.getId(), region);
            }
        }
        //MapEditor.getLog().put("X: " + currentX + ", Y: " + currentY);

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

}
