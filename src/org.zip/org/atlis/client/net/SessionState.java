package org.atlis.client.net;

public enum SessionState {
    DISCONNECTED,
    CONNECTING,
    KEY_EXCHANGE,
    RESPONSE,
    CONNECTED
}
